'''INHERITANCE :- THE PROCESS OF AQUIRING PROPERTIES AND BEHAVIOR FROM ONE TO ANOTHER CLASS IS KNOWN AS INHERITANCE
 THERE ARE FIVE TYPES OF INHERITANCE
 1)- SINGLE LEVEL INHERITANCE :- WHEN A CLASS INHERITS THE PROPERTIES OF ANOTHER IS KNOWN AS SINGLE
 2)- MULTILEVEL INHERITANCE :- WHEN A CLASS INHERITS THE PROPERTIES OF ANOTHER BUT THESE CLASS ALREADY INHERITED ANOTHER CLASS 
 3)- MULTIPLE INHERITANCE :- WHEN A CLASS INHERITS MORE THAN ONE CLASS
 4)- HIERARCHICAL INHERITANCE :- WHEN A CLASS INHERITED BY MORE THAN ONE CLASS
 5)- HYBRID INHERITANCE :- IT IS A COMBINATION OF HIERARCHICAL AND MULTIPLE INHERITANCE 
 '''


# class A:
#     def m1(self):
#         print("hello")
#     def m2(self,a,b):
#         print(a+b)
# class B(A):
#     pass
# b=B()
# b.m1()
# b.m2(2,4)


class A:
    def m1(self):
        print("hi")
class B(A):
    def m2(self):
        print("bye")
class C(B):
    def m3(self):
        print("nikhil")
ob=C()
ob.m3()


'''baki aur v inheritance ka khud se example lekr aao'''




